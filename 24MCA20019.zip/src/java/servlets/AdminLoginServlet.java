package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import database.DBConnection;

@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String username = request.getParameter("adminUsername"); // Fix: Match input field names
        String password = request.getParameter("adminPassword");

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT role FROM users WHERE username = ? AND password = ? AND role = 'admin'")) {

            stmt.setString(1, username); // Fix: Use actual user input
            stmt.setString(2, password);
            
            System.out.println("Executing query: " + stmt.toString()); // Debugging line
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                HttpSession session = request.getSession();
                session.setAttribute("admin", username);
                session.setAttribute("role", "admin");
                response.sendRedirect("adminHome.jsp");
            } else {
                System.out.println("Invalid admin credentials!"); // Debugging line
                response.getWriter().println("<script>alert('Invalid Admin Credentials!');window.location='adminLogin.jsp';</script>");
            }
        } catch (Exception e) {
            e.printStackTrace(); // Print full error in the server console
            response.getWriter().println("<script>alert('Database Error: " + e.getMessage() + "');window.location='adminLogin.jsp';</script>");
        }
    }
}