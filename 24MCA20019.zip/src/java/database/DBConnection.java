package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static Connection conn;

    public static Connection getConnection() throws SQLException {
        try {
            if (conn == null || conn.isClosed()) { // Ensure connection is always open
                Class.forName("com.mysql.cj.jdbc.Driver");
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Employee_DB", "root", "root");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new SQLException("Failed to connect to database");
        }
        return conn;
    }

    // Method to close the connection properly
    public static void closeConnection() {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
                conn = null; // Reset connection
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}